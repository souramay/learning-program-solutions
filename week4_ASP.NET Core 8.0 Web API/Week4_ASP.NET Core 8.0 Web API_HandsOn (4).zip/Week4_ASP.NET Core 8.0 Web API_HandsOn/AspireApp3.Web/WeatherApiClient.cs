namespace AspireApp3.Web;

// Product-related code should be placed here if needed. Otherwise, leave this file empty or remove it if not required.
