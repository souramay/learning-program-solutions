﻿using Microsoft.AspNetCore.Mvc;

namespace AspireApp3.ApiService.Controllers
{
    [ApiController]
    [Route("api/Emp")]
    public class ProductController : ControllerBase
    {
        // Simple in-memory store for demonstration
        private static readonly Dictionary<int, Product> Products = new();
        private static int _nextId = 1;
        // GET
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Product>), 200)]
        [ActionName("GetAllProducts")]
        public ActionResult<IEnumerable<Product>> GetAllProducts()
        {
            return Ok(Products.Values);
        }

        // GET
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(Product), 200)]
        [ProducesResponseType(404)]
        [ActionName("GetProductById")]
        public ActionResult<Product> GetProduct(int id)
        {
            if (Products.TryGetValue(id, out var product))
                return Ok(product);
            return NotFound();
        }

        // POST
        [HttpPost]
        [ProducesResponseType(typeof(Product), 201)]
        [ProducesResponseType(400)]
        [ActionName("CreateProduct")]
        public ActionResult<Product> CreateProduct(ProductCreateRequest request)
        {
            var product = new Product
            {
                Id = _nextId++,
                Name = request.Name,
                Price = request.Price
            };
            
            Products[product.Id] = product;
            return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, product);
        }

        // PUT
        [HttpPut("{id}")]
        [ProducesResponseType(typeof(Product), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ActionName("UpdateProduct")]
        public IActionResult UpdateProduct(int id, ProductUpdateRequest request)
        {
            if (!Products.ContainsKey(id))
                return NotFound();
            
            var product = Products[id];
            product.Name = request.Name;
            product.Price = request.Price;
            
            return Ok(product);
        }

        // DELETE
        [HttpDelete("{id}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        [ActionName("DeleteProduct")]
        public IActionResult DeleteProduct(int id)
        {
            if (!Products.ContainsKey(id))
                return NotFound();
            Products.Remove(id);
            return NoContent();
        }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }

    public class ProductCreateRequest
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }

    public class ProductUpdateRequest
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
