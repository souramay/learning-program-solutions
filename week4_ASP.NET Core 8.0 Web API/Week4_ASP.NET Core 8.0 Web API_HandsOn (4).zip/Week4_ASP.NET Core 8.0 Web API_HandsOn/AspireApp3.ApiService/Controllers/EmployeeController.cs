using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using AspireApp3.ApiService.Models;
using AspireApp3.ApiService.Filters;

namespace AspireApp3.ApiService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [CustomAuthFilter]
    public class EmployeeController : ControllerBase
    {
        // Simple in-memory store for demonstration
        private static readonly Dictionary<int, Employee> Employees = new();
        private static int _nextId = 1;

        public EmployeeController()
        {
            // Create few records if not already created
            if (Employees.Count == 0)
            {
                var standardEmployees = GetStandardEmployeeList();
                foreach (var employee in standardEmployees)
                {
                    Employees[employee.Id] = employee;
                    _nextId = Math.Max(_nextId, employee.Id + 1);
                }
            }
        }

        private List<Employee> GetStandardEmployeeList()
        {
            return new List<Employee>
            {
                new Employee
                {
                    Id = 1,
                    Name = "John Doe",
                    Salary = 50000,
                    Permanent = true,
                    Department = new Department { Id = 1, Name = "IT", Location = "New York" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 1, Name = "C#", Level = "Advanced" },
                        new Skill { Id = 2, Name = "ASP.NET", Level = "Expert" }
                    },
                    DateOfBirth = new DateTime(1990, 1, 15)
                },
                new Employee
                {
                    Id = 2,
                    Name = "Jane Smith",
                    Salary = 60000,
                    Permanent = false,
                    Department = new Department { Id = 2, Name = "HR", Location = "Chicago" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 3, Name = "Communication", Level = "Expert" },
                        new Skill { Id = 4, Name = "Leadership", Level = "Advanced" }
                    },
                    DateOfBirth = new DateTime(1985, 5, 20)
                },
                new Employee
                {
                    Id = 3,
                    Name = "Bob Johnson",
                    Salary = 45000,
                    Permanent = true,
                    Department = new Department { Id = 1, Name = "IT", Location = "New York" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 5, Name = "JavaScript", Level = "Intermediate" },
                        new Skill { Id = 6, Name = "React", Level = "Advanced" }
                    },
                    DateOfBirth = new DateTime(1992, 8, 10)
                }
            };
        }

        // GET: api/Employee
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Employee>), 200)]
        [ProducesResponseType(500)]
        [ActionName("GetAllEmployees")]
        public ActionResult<List<Employee>> GetAllEmployees([FromQuery] bool throwException = false)
        {
            // Throw exception for testing custom exception filter when requested
            if (throwException)
            {
                throw new Exception("Test exception for custom exception filter");
            }
            
            return Ok(Employees.Values.ToList());
        }

        // GET: api/Employee/standard
        [HttpGet("standard")]
        [ProducesResponseType(typeof(List<Employee>), 200)]
        [AllowAnonymous]
        public ActionResult<List<Employee>> GetStandard()
        {
            var standardEmployees = GetStandardEmployeeList();
            return Ok(standardEmployees);
        }

        // GET: api/Employee/{id}
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(Employee), 200)]
        [ProducesResponseType(404)]
        [ActionName("GetEmployeeById")]
        public ActionResult<Employee> GetEmployee(int id)
        {
            if (Employees.TryGetValue(id, out var employee))
                return Ok(employee);
            return NotFound();
        }

        // POST: api/Employee
        [HttpPost]
        [ProducesResponseType(typeof(Employee), 201)]
        [ProducesResponseType(400)]
        [ActionName("CreateEmployee")]
        public ActionResult<Employee> CreateEmployee([FromBody] Employee employee)
        {
            employee.Id = _nextId++;
            Employees[employee.Id] = employee;
            return CreatedAtAction(nameof(GetEmployee), new { id = employee.Id }, employee);
        }

        // PUT: api/Employee/{id}
        [HttpPut("{id}")]
        [ProducesResponseType(typeof(Employee), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ActionName("UpdateEmployee")]
        public IActionResult UpdateEmployee(int id, [FromBody] Employee employee)
        {
            if (!Employees.ContainsKey(id))
                return NotFound();

            employee.Id = id;
            Employees[id] = employee;
            return Ok(employee);
        }

        // DELETE: api/Employee/{id}
        [HttpDelete("{id}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        [ActionName("DeleteEmployee")]
        public IActionResult DeleteEmployee(int id)
        {
            if (!Employees.ContainsKey(id))
                return NotFound();
            
            Employees.Remove(id);
            return NoContent();
        }
    }
}