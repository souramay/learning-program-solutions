using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace AspireApp3.ApiService.Filters
{
    public class CustomExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            // Get exception details
            var exception = context.Exception;
            var exceptionMessage = $"Exception occurred at {DateTime.Now}: {exception.Message}\n" +
                                 $"Stack Trace: {exception.StackTrace}\n" +
                                 $"Request Path: {context.HttpContext.Request.Path}\n" +
                                 $"Request Method: {context.HttpContext.Request.Method}\n" +
                                 "-------------------\n";

            // Write exception to file
            try
            {
                var logPath = Path.Combine(Directory.GetCurrentDirectory(), "logs");
                if (!Directory.Exists(logPath))
                {
                    Directory.CreateDirectory(logPath);
                }
                
                var fileName = Path.Combine(logPath, $"exceptions_{DateTime.Now:yyyy-MM-dd}.log");
                File.AppendAllText(fileName, exceptionMessage);
            }
            catch (Exception logException)
            {
                // If logging fails, we don't want to throw another exception
                System.Diagnostics.Debug.WriteLine($"Failed to log exception: {logException.Message}");
            }

            // Set the result to return internal server error
            context.Result = new ObjectResult(new { error = "Internal server error occurred" })
            {
                StatusCode = 500
            };

            // Mark the exception as handled
            context.ExceptionHandled = true;
        }
    }
}